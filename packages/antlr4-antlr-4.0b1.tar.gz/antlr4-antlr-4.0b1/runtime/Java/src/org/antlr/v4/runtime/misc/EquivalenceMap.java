package org.antlr.v4.runtime.misc;

import java.util.Map;

public interface EquivalenceMap<K,V> extends Map<K,V>, EquivalenceRelation<K> {
}
