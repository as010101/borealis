class Bar {
    private int bitsOrSingle(int bits, int ch) {
        boolean d =
			!(3==4 &&
			  (ch == 0xff || ch == 0xb5 ||
//               ch == 0x53 || ch == 0x73 ||
//               ch == 0x4b || ch == 0x6b ||
               ch == 0xc5 || ch == 0xe5));
        return 9;
    }
}
