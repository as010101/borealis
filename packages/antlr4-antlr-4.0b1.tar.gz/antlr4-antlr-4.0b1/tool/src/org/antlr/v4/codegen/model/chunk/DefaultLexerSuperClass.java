package org.antlr.v4.codegen.model.chunk;

public class DefaultLexerSuperClass extends ActionChunk {
	public DefaultLexerSuperClass() { super(null); }
}
