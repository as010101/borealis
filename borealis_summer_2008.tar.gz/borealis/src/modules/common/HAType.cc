#include "HAType.h"

BOREALIS_NAMESPACE_BEGIN

// --------------------------------------------------
const HAType HAType::PRIMARY = HAType("primary");

const HAType HAType::BACKUP = HAType("backup");

BOREALIS_NAMESPACE_END

