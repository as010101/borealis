#include "AuroraNode.h"

BOREALIS_NAMESPACE_BEGIN

void AuroraNode::DequeueHandle::handle(Time in_time, double latency)
{
}

BOREALIS_NAMESPACE_END
