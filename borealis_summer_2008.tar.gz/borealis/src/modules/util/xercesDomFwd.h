#ifndef XERCESDOMFWD_H
#define XERCESDOMFWD_H

#include <xercesc/dom/DOM.hpp>
#include <xercesc/util/XMLString.hpp>

#include "Exceptions.h"

#ifdef XERCES_CPP_NAMESPACE
using namespace xercesc;
#endif

#endif
