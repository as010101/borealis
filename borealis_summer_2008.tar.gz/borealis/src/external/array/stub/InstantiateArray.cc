#include "QBox.h"
#include "NArgs.h"
#include "Aggregate.h"


BOREALIS_NAMESPACE_BEGIN


////////////////////////////////////////////////////////////////////////////////
//
//  Stub to exclude user defined boxes.
//
QBox  *QBox::instantiate_array(const string  &type)
{
//..............................................................................


    return  NULL;
}


BOREALIS_NAMESPACE_END 
